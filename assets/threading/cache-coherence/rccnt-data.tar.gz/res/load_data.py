import pandas as pd

def load_one(fname):
    ''' Read the file and extract the values of each
        thread (2) for each experiment.

        Return two lists of the form:
         [ [v1, v2, ...], [v3, v4, ...] ]
        where each sublist is the list of values for one
        experiment.

        [
            [v,  v,  v,  v, ...],    # experiment 1
            [v,  v,  v,  v, ...],    # experiment 2
            [v,  v,  v,  v, ...],    # experiment 3
             :   :   :   :                 ::
             ^   ^
             |   |
             spin times to access
             the first element of the array
                 |
                 spin times to access
                 the second element of the array
        ...
        ]

    '''
    a, b = [], []
    t = [a, b]
    with open(fname, 'r') as f:
        for i, line in enumerate(f):
            if i%3 == 2:
                continue

            values = map(int, line.strip().split())
            t[i%3].append(values)

    return a, b


def load():
    dframes = []
    for i in range(32):
        for j in range(32):
            fname = 'res_%i_%i' % (i, j)
            a, b = load_one(fname)

            # each column represent the cycles of the busy loop
            # that the thread did to access the given array index
            # (column i: cycles to access the ith array element)
            a = pd.DataFrame(a)
            b = pd.DataFrame(b)

            # we 'melt' all the columns to form a narrow and very
            # large table with only two columns.
            # the original columns' names are turn into rows
            # under a single column named 'arr_ix'.
            # the original columns' values are turn into rows
            # under a single column named 'cycles'
            a = a.melt(var_name='arr_ix', value_name='cycles')
            b = b.melt(var_name='arr_ix', value_name='cycles')

            # add the 'cpu' column to indicate
            # from which cpu was observed the
            # cycles of the busy-loop
            a['cpu'] = i
            b['cpu'] = j

            # add the 'other cpu' to indicate
            # which other cpu was involved in the experiment.
            a['2nd cpu'] = j
            b['2nd cpu'] = i

            dframes.append(a)
            dframes.append(b)

    # build a huge dataframe with one observation per row
    # and one variable per column.
    # 'ignore_index' will reset the index
    return pd.concat(dframes, ignore_index=True)


# for the same cpu sns.catplot(data=a)


# v0, v1, ....., v7, thread, cpu0, cpu1
#                       0      0    1
#                       1      0    1
