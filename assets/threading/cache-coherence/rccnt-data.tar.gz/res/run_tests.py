import os
for r in range(50):
   print("round", r)
   for i in range(32):
        for j in range(32):
            os.system("./rccnt {i} {j} >> res_{i}_{j}".format(**locals()))

